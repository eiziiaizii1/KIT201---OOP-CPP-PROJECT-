#include "CollisionManager.h"

////DONE TODO 1: IMPLEMENT THE TOP COLLISSION ON Y-AXIS (DO IT AFTER CODING PLAYER JUMP)
////FIXED !!BUG3: GAME ABORTS WHEN PLAYER GOES BEYOND THE SCREEN
////FIXED MINOR BUG4: UNEXPECTED and glitchy BEHAVIOR WHEN the player enters a place that is 2 blocks high 
////FIXED MINOR BUG5: When llower, lupper, ltop happens at the same time player teleports to the lower part of the platform
////FIXED MINOR BUG1: Colliding with the side edges of the tile while airborne causes a glitch
////FIXED MINOR BUG2: holding down to the cliff :D (My the god help me I dont know how to fix that)
////FIXED MINOR BUG6: When player is on the leftmost block's leftmost edge it falls (it is due to large player sprite width), can be fixed or minimized
////FIXED NOTE: CHECKING ONLY BOTTOM MID FOR BOTTOM COLLISIONS SOLVES MOST OF THE PROBLEMS, but when player falls as it goes edge of the block

CollisionManager::CollisionManager(TileMap& tileMap)
{
}

void CollisionManager::handleBottomCollisions(Entity& entity, std::vector<std::vector<short>>& tileMap, short leftTopY, short leftBottomY)
{
	//as we only need these variables here, we don't need to calculate them in handleCollisions() function
	float offSet = (entity.getGlobalBounds().width - tileBounds.width) / 2.f;

	short leftMidBottomX = static_cast<short>(floor((entity.getGlobalBounds().left + offSet) / tileBounds.width));
	short rightMidBottomX =static_cast<short>( floor(((entity.getGlobalBounds().left + entity.getGlobalBounds().width - offSet)) / tileBounds.width));

	// Bottom Collision
	// entity's y index is same for all bottom parts no need to recalculate BottomY index 
	if (tileMap[leftBottomY][leftMidBottomX] == GROUND ||
		tileMap[leftBottomY][rightMidBottomX] == GROUND)
	{
		//std::cout << "BOTTOM\n";
		entity.setPosition
		(
			entity.getPosition().x,
			(tileBounds.height * leftBottomY) - entity.getGlobalBounds().height
		);
		entity.setVelocity(entity.getVelocity().x, 0.f);

		// Setting 'isGrounded' to true here will prevent the player from jumping while falling down.
		entity.setIsGrounded(true);
	}
	else
	{
		entity.setIsGrounded(false);
	}
}

void CollisionManager::handleTopCollisions(
	Entity& entity, std::vector<std::vector<short>>& tileMap, bool& topCollided,
	short leftTopX, short leftTopY, short rightTopX, short rightTopY, short midTopX, short midTopY)
{
	if (entity.getVelocity().y < 0 &&
		(tileMap[leftTopY][leftTopX] == GROUND ||
			tileMap[rightTopY][rightTopX] == GROUND ||
			tileMap[midTopY][midTopX] == GROUND))
	{
		topCollided = true;
		//std::cout << "TOP\n";
		entity.setPosition
		(
			entity.getPosition().x,
			tileBounds.height * (leftTopY + 1)
		);
		entity.setVelocity(entity.getVelocity().x, 0.f);
	}
}

void CollisionManager::handleLeftCollisions(
	Entity& entity, std::vector<std::vector<short>>& tileMap, short leftBottomX, short leftBottomY, short leftTopX, short leftTopY)
{
	// Lower left side collision
	if (tileMap[leftBottomY - 1][leftBottomX] == GROUND)
	{
		//std::cout << "left lower\n";
		entity.setPosition
		(
			tileBounds.width * (leftTopX + 1),
			entity.getPosition().y
		);
		entity.setVelocity(0.f, entity.getVelocity().y);
	}
	// Upper left side collision
	else if (tileMap[leftTopY][leftTopX] == GROUND)
	{
		//std::cout << "left upper\n";
		entity.setPosition
		(
			tileBounds.width * (leftTopX + 1),
			entity.getPosition().y
		);
		entity.setVelocity(0.f, entity.getVelocity().y);
	}
}

void CollisionManager::handleRightCollisions(
	Entity& entity, std::vector<std::vector<short>>& tileMap, short rightTopX, short rightTopY, short rightBottomX, short rightBottomY)
{
	// Lower right side collision
	if (tileMap[rightBottomY - 1][rightBottomX] == GROUND)
	{
		entity.setPosition
		(
			tileBounds.width * rightTopX - entity.getGlobalBounds().width -1.f,
			entity.getPosition().y
		);
		entity.setVelocity(0.f, entity.getVelocity().y);
	}
	// Upper right side collision
	else if (tileMap[rightTopY][rightTopX] == GROUND)
	{
		entity.setPosition
		(
			tileBounds.width * rightTopX - entity.getGlobalBounds().width - 1.f,
			entity.getPosition().y
		);
		entity.setVelocity(0.f, entity.getVelocity().y);
	}
}


void CollisionManager::handleCollisions(Entity& entity, TileMap& tileMap)
{
	std::vector<std::vector<short>>tileMapVector = tileMap.getMapVector();

	// These variables specify the indices that correspond to the corners of the character sprite on the tile map vector
	short leftTopX = static_cast<short>(floor(entity.getGlobalBounds().left / tileBounds.width));
	short leftTopY = static_cast<short>(floor(entity.getGlobalBounds().top/ tileBounds.height));

	short leftBottomX = leftTopX;
	short leftBottomY = static_cast<short>(floor((entity.getGlobalBounds().top + entity.getGlobalBounds().height) / tileBounds.height));

	short rightTopX = static_cast<short>(floor((entity.getGlobalBounds().left + entity.getGlobalBounds().width) / tileBounds.width));
	short rightTopY = leftTopY;

	short rightBottomX = rightTopX;
	short rightBottomY = static_cast<short>(floor((entity.getGlobalBounds().top + entity.getGlobalBounds().height) / tileBounds.height));

	short midTopX = static_cast<short>(floor((entity.getGlobalBounds().left + entity.getGlobalBounds().width+ entity.getGlobalBounds().left) / 2.f / tileBounds.width));
	short midTopY = static_cast<short>(floor(entity.getGlobalBounds().top / tileBounds.height));

	short midBottomX = static_cast<short>(floor((entity.getGlobalBounds().left + entity.getGlobalBounds().width + entity.getGlobalBounds().left) / 2.f / tileBounds.width));
	short midBottomY = static_cast<short>(floor((entity.getGlobalBounds().top + entity.getGlobalBounds().height) / tileBounds.height));


	bool topCollided = false;
	if (leftTopY < 0 || leftBottomY >= tileMapVector.size() || 
		leftTopX < 0 || rightTopX >= tileMapVector[0].size())
	{
		std::cout << "ERROR::CollisionManager::handleCollisions():: player is out of bounds\n";
	}
	else
	{

		handleBottomCollisions(entity, tileMapVector,  leftTopY, leftBottomY);

		handleTopCollisions(entity, tileMapVector, topCollided, leftTopX, leftTopY, rightTopX, rightTopY, midTopX, midTopY);

		if (topCollided == false) 
		{
			handleLeftCollisions(entity, tileMapVector, leftBottomX, leftBottomY, leftTopX, leftTopY);

			handleRightCollisions(entity, tileMapVector, rightTopX, rightTopY, rightBottomX, rightBottomY);
		}
	}
}

void CollisionManager::handleCollisions(std::vector<std::unique_ptr<Bullet>>& bullets, std::vector<std::unique_ptr<Entity>>& entities) {
	
	for (int i = 1; i < entities.size(); i++)
	{
		for (int k = 0; k < bullets.size(); k++)
		{
			// SFML::Intersects() function returns unexpected value, so I had to calculate intersection manually
			if (bullets[k]->getGlobalBounds().left < entities[i]->getGlobalBounds().left + entities[i]->getGlobalBounds().width &&
				bullets[k]->getGlobalBounds().left + bullets[k]->getGlobalBounds().width > entities[i]->getGlobalBounds().left &&
				bullets[k]->getGlobalBounds().top < entities[i]->getGlobalBounds().top + entities[i]->getGlobalBounds().height &&
				bullets[k]->getGlobalBounds().top + bullets[k]->getGlobalBounds().height > entities[i]->getGlobalBounds().top)
			{
				// Makes sure that entity is enemy and enemy is not dead
				// Then deals damage to enemy, if its healt reaches to 0 destroyes it
				if (entities[i]->isEnemy() && entities[i]->getIsDead() == false)
				{
					entities[i]->takeDamage(bullets[k]->getDamage());
					entities[i]->setIsHit(true);
					// Add small force when bullets hit
					bullets[k]->getPosition().x <= entities[i]->getPosition().x ?
						PhysicsManager::addForce(*entities[i], 2.f, -10.f) : PhysicsManager::addForce(*entities[i], -2.f, -10.f);
					bullets.erase(bullets.begin() + k);

					std::cout << "Enemy health:" << entities[i]->getHealth() << "/" << entities[i]->getMaxHealth() << std::endl;
					if (entities[i]->getHealth()<=0)
					{
						entities[i]->setDead();
						entities.erase(entities.begin() + i);
						break;
					}
				}
				break;
			}
		}
	}
}

void CollisionManager::handleCollisions(std::vector<std::unique_ptr<Entity>>& entities)
{
	for (int i = 1; i< entities.size(); i++)
	{
		if (entities[0]->isEnemy() == false && entities[i]->isEnemy() == true &&
			entities[0]->getGlobalBounds().left < entities[i]->getGlobalBounds().left + entities[i]->getGlobalBounds().width &&
			entities[0]->getGlobalBounds().left + entities[0]->getGlobalBounds().width > entities[i]->getGlobalBounds().left &&
			entities[0]->getGlobalBounds().top < entities[i]->getGlobalBounds().top + entities[i]->getGlobalBounds().height &&
			entities[0]->getGlobalBounds().top + entities[0]->getGlobalBounds().height > entities[i]->getGlobalBounds().top)
		{


			entities[0]->getPosition().x <= entities[i]->getPosition().x ?
				PhysicsManager::addForce(*entities[0], (entities[i]->getVelocity().x - 10.f), 0.f)
			  : PhysicsManager::addForce(*entities[0], (entities[i]->getVelocity().x +10.f), 0.f);

			entities[0]->takeDamage(10);
			std::cout << "Player health: "<< entities[0]->getHealth() << "/" << entities[0]->getMaxHealth() << "\n";
		}
	}
}
